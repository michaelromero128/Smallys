package cornez.com.smallys;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class viewOrders extends AppCompatActivity {
    private FirebaseDatabase mFireDB;
    private ChildEventListener mChildEventListener;
    private OrderAdapter mOrderAdapter;
    private ListView mOrderListView;
    private ArrayList<String> orders;
    private DatabaseReference fireDBref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_orders);
        mFireDB = FirebaseDatabase.getInstance();
        fireDBref = mFireDB.getReference().child("Order");
        final List<Order> orders = new ArrayList<>();

      //  orders.add(new Order("Large","Jimmy","Stuffed Crust, Pineapple, Ham"));
      //  orders.add(new Order("Large","Jimmy","Stuffed Crust, Pineapple, Ham"));
       // orders.add(new Order("Large","Jimmy","Stuffed Crust, Pineapple, Ham"));
       // orders.add(new Order("Large","Jimmy","Stuffed Crust, Pineapple, Ham"));

        mOrderListView = (ListView) findViewById(R.id.order_ListView);
        mOrderAdapter = new OrderAdapter(this, R.layout.order_item,orders);

        mOrderListView.setAdapter(mOrderAdapter);

        mChildEventListener = new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Order order = dataSnapshot.getValue(Order.class);
                orders.add(order);
                mOrderAdapter.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                Order order = dataSnapshot.getValue(Order.class);
                mOrderAdapter.remove(order);

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };
        fireDBref.addChildEventListener(mChildEventListener);



    }

}

