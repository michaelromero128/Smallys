package cornez.com.smallys;

import java.util.ArrayList;

public class Order {
    private String size;
    private String toppings;
    private String name;

    public Order() {

    }
    public Order(String size,String name, String toppings) {
        this.size = size;
        this.toppings = toppings;
        this.name = name;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getToppings() {
        return toppings;
    }

    public void setToppings(String toppings) {
        this.toppings = toppings;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {

        this.name = name;
    }
}
