package cornez.com.smallys;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class submit extends AppCompatActivity {

    private FirebaseDatabase fireDB;
    private DatabaseReference fireDBref;
    private ChildEventListener fireChildEventListener;
    private DatabaseReference mDatabase;
    private DatabaseReference mMessageReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.submit);
        fireDB = FirebaseDatabase.getInstance();
        fireDBref = fireDB.getReference().child("Order");





        Button submitB = (Button) findViewById(R.id.submitOrderButton);
        submitB.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String toppings = "Stuffed Crust, Pineapple, Ham";

                Order order = new Order("Large", "Jimmy", toppings );
                fireDBref.push().setValue(order);


              //  mDatabase.child("title").child("ID2222").setValue("JavaSampleApproach");
              //  ArrayList<String> stringer = new ArrayList<>();
               // stringer.add("things");
               // stringer.add("thingers");
                //mDatabase.child("title").child("ID234").setValue(stringer);
               // mDatabase.child("title").child("ID234").removeValue();

            }
        });


        }
    private void displayToast(){
        Toast.makeText(this, "Order Submited", Toast.LENGTH_LONG).show();

    }

}
