package cornez.com.smallys;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.List;

public class OrderAdapter extends ArrayAdapter<Order> {

    public OrderAdapter(Context context, int resource, List<Order> objects){
        super(context,resource,objects);
    }

    public View getView(int position, View convertView, ViewGroup parent){
        if(convertView == null){
            convertView = ((Activity) getContext()).getLayoutInflater().inflate(R.layout.order_item, parent, false);

        }
        TextView orderTextView = (TextView) convertView.findViewById(R.id.orderTextView);
        TextView nameTextView = (TextView) convertView.findViewById(R.id.nameTextView);
        TextView order = (TextView) convertView.findViewById(R.id.orderTextView);
        TextView name = (TextView) convertView.findViewById(R.id.orderTextView);
        Order theOrder = getItem(position);

        String description = theOrder.getSize() + ": " + theOrder.getToppings();
        orderTextView.setText(description);
        nameTextView.setText(theOrder.getName());
        return convertView;
    }
}
